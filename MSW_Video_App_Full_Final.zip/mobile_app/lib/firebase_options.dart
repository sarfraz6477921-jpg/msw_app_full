// Run inject_keys.sh to populate firebase config for mobile
